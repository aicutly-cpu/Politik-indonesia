// Utilitas bersama: pembuatan timing.json dan subtitle SRT.
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';

export const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
export const FPS = 30;
export const INTRO_S = 5;
export const OUTRO_S = 6;
export const MAX_CHARS = 88;
export const narration = JSON.parse(fs.readFileSync(path.join(ROOT, 'src/narration.json'), 'utf8'));

const r3 = (x) => Math.round(x * 1000) / 1000;

export function chunkText(text) {
  const n = Math.max(1, Math.ceil(text.length / MAX_CHARS));
  const target = (text.length / n) * 1.1;
  const out = [];
  let cur = '';
  for (const w of text.split(/\s+/)) {
    const next = cur ? `${cur} ${w}` : w;
    if (cur && next.length > target) {
      out.push(cur);
      cur = w;
    } else cur = next;
  }
  if (cur) out.push(cur);
  return out;
}

export function buildTiming(durs, audio) {
  let t = 0;
  const lines = [];
  const cues = [];
  narration.forEach((n, i) => {
    const start = t;
    const end = t + durs[i];
    lines.push({id: i + 1, text: n.text, start: r3(start), end: r3(end)});
    const chunks = chunkText(n.text);
    const total = chunks.reduce((a, c) => a + c.length, 0);
    let cs = start;
    for (const c of chunks) {
      const ce = cs + (durs[i] * c.length) / total;
      cues.push({start: r3(cs), end: r3(ce), text: c});
      cs = ce;
    }
    t = end + n.pause;
  });
  const narrationSec = r3(lines[lines.length - 1].end + 0.8);
  return {fps: FPS, introSec: INTRO_S, outroSec: OUTRO_S, audio, narrationSec, lines, cues};
}

const ts = (s) => {
  const ms = Math.round(s * 1000);
  const p = (n, l = 2) => String(n).padStart(l, '0');
  return `${p(Math.floor(ms / 3600000))}:${p(Math.floor(ms / 60000) % 60)}:${p(Math.floor(ms / 1000) % 60)},${p(ms % 1000, 3)}`;
};

export function writeAll(timing) {
  fs.writeFileSync(path.join(ROOT, 'src/timing.json'), JSON.stringify(timing, null, 2) + '\n');
  const srt = timing.cues
    .map((c, i) => `${i + 1}\n${ts(c.start + INTRO_S)} --> ${ts(c.end + INTRO_S)}\n${c.text}\n`)
    .join('\n');
  fs.mkdirSync(path.join(ROOT, 'public/subtitles'), {recursive: true});
  fs.writeFileSync(path.join(ROOT, 'public/subtitles/narration.srt'), srt);
  const total = INTRO_S + timing.narrationSec + OUTRO_S;
  console.log(`timing.json + narration.srt ditulis. Audio=${timing.audio}. Durasi video ≈ ${total.toFixed(1)} dtk (${(total / 60).toFixed(2)} menit).`);
}
