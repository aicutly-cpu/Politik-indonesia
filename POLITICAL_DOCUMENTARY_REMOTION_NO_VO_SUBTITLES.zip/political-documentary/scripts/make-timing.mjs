// Membuat timing.json + SRT.
//  - tanpa argumen      : timing PERKIRAAN (belum ada audio)
//  - --audio=<file.mp3> : skala timing perkiraan ke durasi asli rekaman Anda (sinkron kasar)
import {execFileSync} from 'node:child_process';
import {narration, buildTiming, writeAll} from './lib.mjs';

const est = narration.map((n) => Math.max(1.2, n.text.length / 13.5));
const arg = process.argv.find((a) => a.startsWith('--audio='));
let timing;
if (arg) {
  const file = arg.split('=')[1];
  const dur = parseFloat(
    execFileSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file]).toString(),
  );
  const pauses = narration.slice(0, -1).reduce((a, n) => a + n.pause, 0);
  const k = (dur - pauses) / est.reduce((a, b) => a + b, 0);
  if (!(k > 0.3)) throw new Error('Durasi audio terlalu pendek dibanding naskah.');
  timing = buildTiming(est.map((d) => d * k), true);
  timing.narrationSec = Math.round((dur + 0.3) * 1000) / 1000;
} else {
  timing = buildTiming(est, false);
}
writeAll(timing);
