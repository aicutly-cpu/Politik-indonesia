// Pemeriksaan aset sebelum render: timing visual dan musik latar.
import fs from 'node:fs';
import path from 'node:path';
import {ROOT} from './lib.mjs';
const p = (f) => path.join(ROOT, f);
const errors = [];
['src/timing.json', 'src/narration.json', 'public/audio/ambient.mp3'].forEach((f) => {
  if (!fs.existsSync(p(f))) errors.push(`Tidak ditemukan: ${f}`);
});
if (!errors.length) {
  const t = JSON.parse(fs.readFileSync(p('src/timing.json'), 'utf8'));
  const narration = JSON.parse(fs.readFileSync(p('src/narration.json'), 'utf8'));
  if (t.lines.length !== narration.length) errors.push('Jumlah baris timing.json tidak sama dengan narration.json.');
  narration.forEach((n, i) => {
    if (t.lines[i] && t.lines[i].text !== n.text) errors.push(`Teks baris ${i + 1} berbeda dari narration.json.`);
  });
}
if (errors.length) { errors.forEach((e) => console.error('ERROR:', e)); process.exit(1); }
console.log('Pemeriksaan aset OK. Video dirender tanpa voice-over dan subtitle.');
