import {Config} from '@remotion/cli/config';

Config.setVideoImageFormat('jpeg');
Config.setCodec('h264');
Config.setPixelFormat('yuv420p');
Config.setCrf(18);
Config.setOverwriteOutput(true);

// Opsional: pakai Chrome/Chromium yang sudah terpasang di sistem.
// Contoh: CHROMIUM_PATH=/usr/bin/chromium npm run render
// Kalau kosong, Remotion memakai Chrome Headless Shell hasil `npm run browser`.
if (process.env.CHROMIUM_PATH) {
  Config.setBrowserExecutable(process.env.CHROMIUM_PATH);
}
