#!/usr/bin/env bash
# Render video MP4 (1920x1080, 30 fps, H.264).
set -euo pipefail
cd "$(dirname "$0")"
mkdir -p out
[ -d node_modules ] || npm install
npx remotion browser ensure
node scripts/check-assets.mjs
npx remotion render src/index.ts PoliticalDocumentary out/skandal-penyadapan.mp4 \
  --codec=h264 --crf=18 --concurrency="${CONCURRENCY:-2}"
echo "Selesai: out/skandal-penyadapan.mp4"
