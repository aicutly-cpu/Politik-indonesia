# Dokumenter Politik: Skandal Penyadapan Ilegal

Proyek video dokumenter 1920×1080, 30 fps, MP4 (H.264), dibuat dengan **Remotion + React + TypeScript**.

## Perubahan sesuai revisi

- **Tidak ada subtitle atau animasi teks yang mengikuti voice-over** di hasil render.
- **Tidak ada file voice-over yang diputar atau dibuat otomatis** oleh proyek ini.
- Animasi visual, judul pembuka/penutup, grafis, ikon, dan teks desain yang memang menjadi bagian adegan tetap dipertahankan.
- Musik ambient tetap digunakan sebagai musik latar.
- Naskah di `src/narration.json` tetap disimpan sebagai bahan referensi untuk membuat voice-over sendiri.
- Timing adegan tetap memakai perkiraan durasi narasi sekitar 3 menit 13 detik. Jika nanti voice-over buatan sendiri memiliki durasi berbeda, timing adegan bisa disesuaikan.

## Menjalankan proyek

### Dari Linux/PC

```bash
npm install
npm run browser
npm run typecheck
npm run check
npm run preview
npm run render
```

Hasil render: `out/skandal-penyadapan.mp4`.

### Dari Android

Remotion memerlukan Chrome/Chromium headless dan tidak berjalan langsung di Termux. Cara yang disarankan adalah mengunggah proyek ke GitHub lalu menjalankan workflow **Render video** melalui GitHub Actions.

1. Ekstrak ZIP.
2. Buat repository GitHub kosong.
3. Unggah seluruh isi folder proyek.
4. Buka tab **Actions** lalu jalankan workflow **Render video**.
5. Unduh artifact hasil render.

Workflow hanya memasang dependensi, memeriksa aset, dan merender video. Tidak ada proses pembuatan voice-over otomatis.

## Struktur penting

```text
public/audio/ambient.mp3   musik latar
src/narration.json         naskah voice-over sebagai referensi
src/timing.json            timing perkiraan untuk durasi adegan
src/scenes/                adegan dan motion graphic
src/animations/            komponen animasi visual
src/Video.tsx              susunan komposisi video
```

## Mengubah durasi

Durasi narasi perkiraan dan pembagian adegan diatur melalui `src/timing.json` serta `src/timeline.ts`. Jika voice-over buatan sendiri nanti lebih panjang atau lebih pendek, sesuaikan timing tersebut agar pergantian adegan cocok dengan audio yang akan ditambahkan di aplikasi editor.

## Catatan

Visual dalam proyek ini bersifat ilustratif. Teks judul, label, dan elemen grafis yang merupakan bagian dari desain adegan tetap ada; yang dihapus adalah subtitle/teks berjalan yang menampilkan isi voice-over.
