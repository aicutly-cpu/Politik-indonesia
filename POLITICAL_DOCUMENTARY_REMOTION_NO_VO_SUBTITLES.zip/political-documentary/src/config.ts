export const TITLE_MAIN = 'SKANDAL PENYADAPAN ILEGAL';
export const TITLE_SUB = 'yang Menyeret Petinggi Polri dan Presiden Prabowo';
export const DISCLAIMER = [
  'Narasi disusun dari pemberitaan publik hingga 18 November 2026.',
  'Semua pihak yang disebut berstatus dugaan/terduga sampai ada putusan hukum yang berkekuatan tetap.',
  'Seluruh visual bersifat ilustratif dan bukan rekaman asli kejadian.',
];
