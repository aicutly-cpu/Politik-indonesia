import {FC, ReactNode} from 'react';
import {AbsoluteFill, interpolate, useCurrentFrame, useVideoConfig} from 'remotion';
import {C} from '../styles/theme';

type Props = {children: ReactNode; zoom?: [number, number]; pan?: [number, number]; glow?: string};

/** Latar gelap + gerakan kamera (zoom/pan) + fade in/out antar adegan + vignette. */
export const Shell: FC<Props> = ({children, zoom = [1, 1.07], pan = [0, 0], glow = '#1b2a44'}) => {
  const f = useCurrentFrame();
  const {durationInFrames: d} = useVideoConfig();
  const p = f / d;
  const op = interpolate(f, [0, 10, d - 10, d], [0, 1, 1, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'});
  const sc = zoom[0] + (zoom[1] - zoom[0]) * p;
  return (
    <AbsoluteFill style={{background: C.bg, opacity: op}}>
      <AbsoluteFill style={{background: `radial-gradient(ellipse at ${30 + p * 25}% 40%, ${glow} 0%, transparent 62%)`}} />
      <AbsoluteFill style={{transform: `scale(${sc}) translate(${pan[0] * p}px, ${pan[1] * p}px)`}}>{children}</AbsoluteFill>
      <AbsoluteFill style={{background: 'repeating-linear-gradient(0deg, rgba(255,255,255,0.025) 0 1px, transparent 1px 4px)', pointerEvents: 'none'}} />
      <AbsoluteFill style={{background: 'radial-gradient(ellipse at center, transparent 45%, rgba(0,0,0,0.78) 100%)', pointerEvents: 'none'}} />
    </AbsoluteFill>
  );
};
