import {FC, CSSProperties} from 'react';

const FILL = '#0f1520';
const EDGE = '#26334a';
const WIN = '#e0a84a';
type P = {w?: number; style?: CSSProperties};

const Windows: FC<{x: number; y: number; cols: number; rows: number; dx: number; dy: number}> = ({x, y, cols, rows, dx, dy}) => (
  <g fill={WIN} stroke="none">
    {Array.from({length: rows * cols}, (_, k) => {
      const r = Math.floor(k / cols);
      const c = k % cols;
      return <rect key={k} x={x + c * dx} y={y + r * dy} width={dx * 0.4} height={dy * 0.45} opacity={(k * 7) % 5 === 0 ? 0.55 : 0.12} />;
    })}
  </g>
);

/** Siluet gedung pemerintahan generik. */
export const GovBuilding: FC<P> = ({w = 1200, style}) => (
  <svg width={w} viewBox="0 0 1000 420" style={style}>
    <g fill={FILL} stroke={EDGE} strokeWidth={2}>
      <rect x="60" y="380" width="880" height="24" />
      <rect x="90" y="356" width="820" height="24" />
      <rect x="130" y="200" width="740" height="156" />
      <polygon points="110,200 500,90 890,200" />
      {Array.from({length: 8}, (_, i) => <rect key={i} x={160 + i * 90} y={214} width={34} height={142} fill="#080b11" />)}
      <rect x="498" y="20" width="4" height="70" />
    </g>
  </svg>
);

/** Siluet gedung kepolisian generik (menara + sayap). */
export const PoliceBuilding: FC<P> = ({w = 1000, style}) => (
  <svg width={w} viewBox="0 0 1000 520" style={style}>
    <g fill={FILL} stroke={EDGE} strokeWidth={2}>
      <rect x="380" y="90" width="240" height="410" />
      <rect x="498" y="8" width="4" height="82" />
      <rect x="70" y="270" width="310" height="230" />
      <rect x="620" y="270" width="310" height="230" />
      <rect x="40" y="496" width="920" height="16" />
    </g>
    <Windows x={405} y={115} cols={5} rows={9} dx={42} dy={40} />
    <Windows x={95} y={295} cols={6} rows={4} dx={48} dy={50} />
    <Windows x={645} y={295} cols={6} rows={4} dx={48} dy={50} />
  </svg>
);

/** Siluet gedung parlemen generik (kubah + sayap). */
export const Parliament: FC<P> = ({w = 1200, style}) => (
  <svg width={w} viewBox="0 0 1000 400" style={style}>
    <g fill={FILL} stroke={EDGE} strokeWidth={2}>
      <rect x="40" y="340" width="920" height="30" />
      <rect x="80" y="250" width="320" height="90" />
      <rect x="600" y="250" width="320" height="90" />
      <rect x="400" y="200" width="200" height="140" />
      <path d="M390 200 A110 110 0 0 1 610 200 Z" />
      <rect x="498" y="50" width="4" height="40" />
    </g>
    <Windows x={105} y={265} cols={8} rows={2} dx={36} dy={34} />
    <Windows x={625} y={265} cols={8} rows={2} dx={36} dy={34} />
  </svg>
);
