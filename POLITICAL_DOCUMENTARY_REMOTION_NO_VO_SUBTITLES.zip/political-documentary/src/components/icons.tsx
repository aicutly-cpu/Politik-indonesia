import {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {C} from '../styles/theme';

type IconProps = {size?: number; color?: string};
const Svg: FC<IconProps & {children: React.ReactNode}> = ({size = 120, color = C.text, children}) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth={1.2} strokeLinecap="round" strokeLinejoin="round">
    {children}
  </svg>
);

export const MicIcon: FC<IconProps> = (p) => (
  <Svg {...p}><rect x="9" y="3" width="6" height="11" rx="3" /><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6" /></Svg>
);
export const CctvIcon: FC<IconProps> = (p) => (
  <Svg {...p}><path d="M3 8l13-3 2 5-13 3z" /><path d="M10 14l-1 6M6 20h6M18 10l3-.8" /></Svg>
);
export const PhoneIcon: FC<IconProps> = (p) => (
  <Svg {...p}><rect x="7" y="2" width="10" height="20" rx="2" /><path d="M11 18h2" /></Svg>
);
export const ScalesIcon: FC<IconProps> = (p) => (
  <Svg {...p}><path d="M12 3v18M6 21h12M4 7h16M7 7l-3 7a3 3 0 0 0 6 0zM17 7l-3 7a3 3 0 0 0 6 0z" /></Svg>
);
export const EyeIcon: FC<IconProps> = (p) => (
  <Svg {...p}><path d="M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z" /><circle cx="12" cy="12" r="3" /></Svg>
);
export const LockIcon: FC<IconProps> = (p) => (
  <Svg {...p}><rect x="5" y="11" width="14" height="10" rx="2" /><path d="M8 11V8a4 4 0 0 1 8 0v3" /></Svg>
);
export const DocIcon: FC<IconProps> = (p) => (
  <Svg {...p}><path d="M6 2h9l4 4v16H6zM14 2v5h5M9 12h7M9 16h7" /></Svg>
);

/** Gelombang sinyal yang memancar. */
export const Waves: FC<{size: number; color?: string; at?: number}> = ({size, color = C.red, at = 0}) => {
  const f = useCurrentFrame();
  return (
    <svg width={size} height={size} viewBox="-50 -50 100 100">
      {[0, 1, 2, 3].map((i) => {
        const raw = ((f - at) / 90 + i / 4) % 1;
        const p = raw < 0 ? raw + 1 : raw;
        return <circle key={i} r={p * 48} fill="none" stroke={color} strokeWidth={0.6} opacity={f >= at ? (1 - p) * 0.8 : 0} />;
      })}
    </svg>
  );
};

/** Lingkaran bidik (ilustrasi "sasaran" pengungkapan). */
export const Reticle: FC<{size: number; color?: string}> = ({size, color = C.red}) => {
  const f = useCurrentFrame();
  const s = 1 + Math.sin(f / 12) * 0.03;
  return (
    <svg width={size} height={size} viewBox="-50 -50 100 100" style={{transform: `scale(${s})`}} fill="none" stroke={color} strokeWidth={0.7}>
      <circle r="44" /><circle r="30" /><circle r="14" />
      <path d="M-50 0H-34M34 0H50M0-50V-34M0 34V50" />
    </svg>
  );
};
