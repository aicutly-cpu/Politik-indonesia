import {FC, CSSProperties} from 'react';
import {useCurrentFrame} from 'remotion';
import {ramp} from '../animations/anim';
import {C, sans, serif} from '../styles/theme';

export const Chip: FC<{text: string; at: number; color?: string; size?: number; style?: CSSProperties}> = ({text, at, color = C.text, size = 38, style}) => {
  const f = useCurrentFrame();
  const p = ramp(f, at, 16);
  return (
    <div style={{display: 'inline-block', padding: '14px 28px', border: `2px solid ${color}`, color, fontFamily: sans, fontWeight: 700, fontSize: size, letterSpacing: 3, background: 'rgba(8,11,17,0.75)', opacity: p, transform: `translateX(${(1 - p) * -40}px)`, ...style}}>
      {text}
    </div>
  );
};

/** Kartu headline bergaya media investigasi (teks dari narasi, bukan kutipan media). */
export const HeadlineCard: FC<{kicker: string; title: string; at: number; width?: number; style?: CSSProperties}> = ({kicker, title, at, width = 1000, style}) => {
  const f = useCurrentFrame();
  const p = ramp(f, at, 18);
  return (
    <div style={{width, background: '#e9e6df', color: '#111', padding: '26px 34px', fontFamily: serif, opacity: p, transform: `translateY(${(1 - p) * 40}px) rotate(-0.6deg)`, boxShadow: '0 20px 60px rgba(0,0,0,0.6)', ...style}}>
      <div style={{fontFamily: sans, fontWeight: 800, fontSize: 22, letterSpacing: 4, color: C.red}}>{kicker}</div>
      <div style={{fontSize: 52, fontWeight: 700, lineHeight: 1.1, marginTop: 10}}>{title}</div>
      <div style={{height: 3, background: '#111', marginTop: 16, width: `${p * 100}%`}} />
    </div>
  );
};
