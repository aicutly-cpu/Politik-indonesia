import {FC, CSSProperties} from 'react';
import {Easing, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {C, serif} from '../styles/theme';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;

/** 0 -> 1 mulai frame `at` selama `dur` frame. */
export const ramp = (f: number, at: number, dur = 14) =>
  interpolate(f, [at, at + dur], [0, 1], {...clamp, easing: Easing.out(Easing.cubic)});

/** Muncul di frame a, hilang di frame b (fade `d` frame). */
export const win = (f: number, a: number, b: number, d = 10) =>
  interpolate(f, [a, a + d, b - d, b], [0, 1, 1, 0], clamp);

type WordsProps = {
  text: string;
  at: number;
  size?: number;
  color?: string;
  font?: string;
  weight?: number;
  stagger?: number;
  align?: 'left' | 'center' | 'right';
  spacing?: number;
  style?: CSSProperties;
};

/** Teks kinetik: kata muncul satu per satu. */
export const Words: FC<WordsProps> = ({
  text, at, size = 64, color = C.text, font = serif, weight = 700, stagger = 3, align = 'center', spacing = 0, style,
}) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  return (
    <div style={{fontFamily: font, fontSize: size, fontWeight: weight, color, textAlign: align, letterSpacing: spacing, lineHeight: 1.15, ...style}}>
      {text.split(' ').map((w, i) => {
        const s = spring({frame: Math.max(0, f - at - i * stagger), fps, config: {damping: 200}});
        return (
          <span key={i} style={{display: 'inline-block', opacity: s, transform: `translateY(${(1 - s) * 28}px)`, marginRight: '0.3em'}}>
            {w}
          </span>
        );
      })}
    </div>
  );
};
