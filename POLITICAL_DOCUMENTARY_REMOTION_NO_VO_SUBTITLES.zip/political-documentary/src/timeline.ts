import timing from './timing.json';

export const FPS: number = timing.fps;
export const INTRO = Math.round(timing.introSec * FPS);
export const OUTRO = Math.round(timing.outroSec * FPS);
export const NARR = Math.ceil(timing.narrationSec * FPS);
export const TOTAL_FRAMES = INTRO + NARR + OUTRO;
export const HAS_AUDIO: boolean = timing.audio;

export type Line = {id: number; text: string; start: number; end: number};
export type Cue = {start: number; end: number; text: string};
export const lines = timing.lines as Line[];
export const cues = timing.cues as Cue[];

const toFrame = (s: number) => Math.round(s * FPS) + INTRO;
const find = (id: number) => {
  const l = lines.find((x) => x.id === id);
  if (!l) throw new Error(`Baris narasi ${id} tidak ada di timing.json`);
  return l;
};
export const lineFrames = (id: number) => ({from: toFrame(find(id).start), to: toFrame(find(id).end)});

const DEFS = [
  {id: 'opening', lines: [1, 2, 3]},
  {id: 'paradox', lines: [4]},
  {id: 'origin', lines: [5, 6]},
  {id: 'targets', lines: [7]},
  {id: 'investigation', lines: [8]},
  {id: 'verdict', lines: [9, 10, 11, 12, 13]},
  {id: 'questions', lines: [14, 15, 16, 17]},
  {id: 'democracy', lines: [18, 19, 20]},
  {id: 'closing', lines: [21, 22, 23, 24]},
];

export const scenes = DEFS.map((d, i) => {
  const from = i === 0 ? INTRO : lineFrames(d.lines[0]).from;
  const end = i === DEFS.length - 1 ? INTRO + NARR : lineFrames(DEFS[i + 1].lines[0]).from;
  return {id: d.id, from, dur: end - from};
});
