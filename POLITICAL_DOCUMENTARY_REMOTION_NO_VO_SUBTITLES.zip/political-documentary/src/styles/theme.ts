export const C = {
  bg: '#06080c',
  panel: '#0d1117',
  line: '#232d3b',
  text: '#eef0f3',
  muted: '#8b95a3',
  red: '#d23b2e',
  amber: '#e0a84a',
};
export const serif = "Georgia, 'Times New Roman', 'Liberation Serif', serif";
export const sans = "'Helvetica Neue', Arial, 'Liberation Sans', sans-serif";
export const mono = "'Courier New', 'Liberation Mono', monospace";
