import {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {Words, ramp} from '../animations/anim';
import {Reticle} from '../components/icons';
import {Shell} from '../components/Shell';
import {lineFrames} from '../timeline';
import {C, mono, sans} from '../styles/theme';

const ITEMS = ['PEJABAT PEMERINTAH', 'ANGGOTA PARLEMEN', 'TOKOH POLITIK', 'AKTIVIS', 'MAHASISWA'];

export const Targets: FC<{t0: number}> = ({t0}) => {
  const f = useCurrentFrame();
  const {from, to} = lineFrames(7);
  const s = from - t0;
  const step = (to - from) / 6;
  return (
    <Shell glow="#1b2a44" zoom={[1, 1.06]}>
      <div style={{position: 'absolute', right: 100, top: 130, opacity: 0.35}}>
        <Reticle size={760} />
      </div>
      <div style={{position: 'absolute', left: 140, top: 90, width: 1200}}>
        <Words text="JUGA DISEBUT DALAM PENGUNGKAPAN" at={4} size={52} align="left" color={C.muted} />
      </div>
      {ITEMS.map((t, i) => {
        const p = ramp(f, s + i * step, 16);
        return (
          <div key={t} style={{position: 'absolute', left: 140, top: 240 + i * 118, display: 'flex', alignItems: 'center', gap: 30, opacity: p, transform: `translateX(${(1 - p) * -60}px)`}}>
            <span style={{fontFamily: mono, color: C.red, fontSize: 40}}>{String(i + 1).padStart(2, '0')}</span>
            <span style={{fontFamily: sans, fontWeight: 800, fontSize: 60, letterSpacing: 3, color: C.text}}>{t}</span>
          </div>
        );
      })}
    </Shell>
  );
};
