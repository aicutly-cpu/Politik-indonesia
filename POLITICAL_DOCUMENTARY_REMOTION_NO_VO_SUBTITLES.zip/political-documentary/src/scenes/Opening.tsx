import {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {Words, ramp} from '../animations/anim';
import {Chip} from '../components/Chip';
import {MicIcon, PhoneIcon} from '../components/icons';
import {Shell} from '../components/Shell';
import {GovBuilding} from '../components/skylines';
import {lineFrames} from '../timeline';
import {C, mono} from '../styles/theme';

export const Opening: FC<{t0: number}> = ({t0}) => {
  const f = useCurrentFrame();
  const at = (i: number) => lineFrames(i).from - t0;
  return (
    <Shell zoom={[1, 1.12]} pan={[0, -30]}>
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 120, display: 'flex', justifyContent: 'center', opacity: 0.9}}>
        <GovBuilding w={1500} />
      </div>
      <div style={{position: 'absolute', left: 120, top: 110, opacity: ramp(f, at(1)), fontFamily: mono, color: C.amber, fontSize: 34, letterSpacing: 8}}>
        NOVEMBER 2026
      </div>
      <div style={{position: 'absolute', left: 120, top: 175, width: 1300}}>
        <Words text="DUGAAN PENYADAPAN ILEGAL" at={at(2)} size={96} align="left" />
        <div style={{height: 6, marginTop: 20, background: C.red, width: `${ramp(f, at(2) + 10, 30) * 520}px`}} />
      </div>
      <div style={{position: 'absolute', right: 140, top: 130, display: 'flex', gap: 40, opacity: ramp(f, at(3))}}>
        <MicIcon size={110} color={C.red} />
        <PhoneIcon size={110} />
      </div>
      <Chip text="PETINGGI KEPOLISIAN" at={at(3)} style={{position: 'absolute', left: 120, top: 470}} />
      <Chip text="KOMUNIKASI PRESIDEN" at={at(3) + 28} color={C.amber} style={{position: 'absolute', left: 120, top: 570}} />
    </Shell>
  );
};
