import {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {Words, ramp} from '../animations/anim';
import {Shell} from '../components/Shell';
import {PoliceBuilding} from '../components/skylines';
import {C, serif} from '../styles/theme';

export const Paradox: FC<{t0: number}> = () => {
  const f = useCurrentFrame();
  return (
    <Shell glow="#1a1f33" zoom={[1.08, 1]} pan={[-40, 0]}>
      <div style={{position: 'absolute', left: 80, bottom: 150, opacity: 0.95}}>
        <PoliceBuilding w={900} />
      </div>
      <div style={{position: 'absolute', right: 140, top: 130, width: 800}}>
        <Words text="INSTITUSI PENJAGA KEAMANAN NEGARA" at={6} size={58} align="left" />
        <div style={{fontFamily: serif, fontSize: 420, color: C.red, lineHeight: 1, marginTop: 40, opacity: ramp(f, 60, 20), transform: `scale(${1 + Math.sin(f / 10) * 0.02})`}}>?</div>
      </div>
    </Shell>
  );
};
