import {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {Words, ramp} from '../animations/anim';
import {Shell} from '../components/Shell';
import {DISCLAIMER, TITLE_MAIN, TITLE_SUB} from '../config';
import {C, mono, sans, serif} from '../styles/theme';

export const Intro: FC = () => {
  const f = useCurrentFrame();
  return (
    <Shell glow="#2a1216" zoom={[1, 1.06]}>
      <div style={{position: 'absolute', top: 250, left: 0, right: 0, textAlign: 'center', fontFamily: mono, color: C.amber, fontSize: 32, letterSpacing: 10, opacity: ramp(f, 0)}}>
        INVESTIGASI · DOKUMENTER POLITIK
      </div>
      <div style={{position: 'absolute', top: 340, left: 120, right: 120}}>
        <Words text={TITLE_MAIN} at={12} size={118} spacing={2} />
        <div style={{height: 6, background: C.red, margin: '26px auto', width: `${ramp(f, 40, 30) * 620}px`}} />
        <Words text={TITLE_SUB} at={50} size={50} weight={400} font={serif} color={C.muted} />
      </div>
    </Shell>
  );
};

export const Outro: FC = () => {
  const f = useCurrentFrame();
  return (
    <Shell glow="#2a1216" zoom={[1.04, 1]}>
      <div style={{position: 'absolute', top: 260, left: 0, right: 0, textAlign: 'center'}}>
        <Words text={TITLE_MAIN} at={0} size={84} />
        <div style={{height: 5, background: C.red, margin: '28px auto', width: `${ramp(f, 20, 30) * 480}px`}} />
      </div>
      <div style={{position: 'absolute', top: 560, left: 220, right: 220, textAlign: 'center', fontFamily: sans, color: C.muted, fontSize: 30, lineHeight: 1.6, opacity: ramp(f, 40, 30)}}>
        {DISCLAIMER.map((d) => <div key={d}>{d}</div>)}
      </div>
    </Shell>
  );
};
