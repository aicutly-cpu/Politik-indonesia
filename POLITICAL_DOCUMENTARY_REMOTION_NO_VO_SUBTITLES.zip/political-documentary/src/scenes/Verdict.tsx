import {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {ramp} from '../animations/anim';
import {Chip, HeadlineCard} from '../components/Chip';
import {Shell} from '../components/Shell';
import {lineFrames} from '../timeline';
import {C, mono, sans} from '../styles/theme';

const NODES = [
  {id: 9, big: '17 NOV', small: 'PERKEMBANGAN BARU'},
  {id: 10, big: 'PTDH', small: 'SIDANG ETIK KEPOLISIAN'},
  {id: 11, big: 'HAMPIR 9 JAM', small: 'DURASI SIDANG'},
  {id: 12, big: 'BANDING', small: 'DIAJUKAN'},
];

export const Verdict: FC<{t0: number}> = ({t0}) => {
  const f = useCurrentFrame();
  const at = (i: number) => lineFrames(i).from - t0;
  const x = (i: number) => 260 + i * 460;
  return (
    <Shell glow="#241a14" zoom={[1, 1.06]}>
      <HeadlineCard kicker="SIDANG ETIK" title="Eko Hadi Santoso dijatuhi sanksi pemberhentian tidak dengan hormat" at={at(10)} width={1050} style={{position: 'absolute', left: 140, top: 100}} />
      <Chip text="PERHATIAN PUBLIK TERTUJU" at={at(13)} color={C.amber} size={32} style={{position: 'absolute', left: 1300, top: 190}} />
      <div style={{position: 'absolute', left: x(0), top: 560, height: 4, background: C.line, width: `${ramp(f, at(9), at(12) - at(9) + 20) * (x(3) - x(0))}px`}} />
      {NODES.map((n, i) => {
        const p = ramp(f, at(n.id), 16);
        return (
          <div key={n.id} style={{position: 'absolute', left: x(i) - 200, top: 440, width: 400, textAlign: 'center', opacity: p, transform: `translateY(${(1 - p) * 30}px)`}}>
            <div style={{fontFamily: sans, fontWeight: 900, fontSize: n.big.length > 8 ? 52 : 70, color: i === 1 ? C.red : C.text}}>{n.big}</div>
            <div style={{width: 26, height: 26, borderRadius: 13, background: C.red, margin: '26px auto 20px'}} />
            <div style={{fontFamily: mono, fontSize: 26, letterSpacing: 3, color: C.muted}}>{n.small}</div>
          </div>
        );
      })}
    </Shell>
  );
};
