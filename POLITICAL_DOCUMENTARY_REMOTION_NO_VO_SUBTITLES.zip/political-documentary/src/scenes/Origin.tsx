import {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {Words, ramp} from '../animations/anim';
import {Chip} from '../components/Chip';
import {PhoneIcon, Waves} from '../components/icons';
import {Shell} from '../components/Shell';
import {Parliament} from '../components/skylines';
import {lineFrames} from '../timeline';
import {C} from '../styles/theme';

export const Origin: FC<{t0: number}> = ({t0}) => {
  const f = useCurrentFrame();
  const at = (i: number) => lineFrames(i).from - t0;
  return (
    <Shell glow="#2a1420" zoom={[1, 1.1]}>
      <div style={{position: 'absolute', left: 0, right: 0, bottom: 130, display: 'flex', justifyContent: 'center', opacity: 0.8 * ramp(f, at(6), 30)}}>
        <Parliament w={1300} />
      </div>
      <div style={{position: 'absolute', left: 560, top: 60, width: 800, height: 800, display: 'flex', alignItems: 'center', justifyContent: 'center'}}>
        <div style={{position: 'absolute'}}><Waves size={800} at={at(5)} /></div>
        <div style={{opacity: ramp(f, at(5))}}><PhoneIcon size={200} /></div>
      </div>
      <div style={{position: 'absolute', top: 70, left: 0, right: 0}}>
        <Words text="KOMUNIKASI PRESIDEN" at={at(5)} size={64} spacing={4} />
      </div>
      <Chip text="KAPOLRI  →  KOMISI III DPR" at={at(6)} color={C.amber} style={{position: 'absolute', left: 120, top: 620}} />
      <div style={{position: 'absolute', left: 120, top: 720, width: 1100}}>
        <Words text="TIDAK HANYA LINGKUNGAN KEPRESIDENAN" at={at(6) + 40} size={50} align="left" />
      </div>
    </Shell>
  );
};
