import {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {ramp} from '../animations/anim';
import {CctvIcon} from '../components/icons';
import {Shell} from '../components/Shell';
import {PoliceBuilding} from '../components/skylines';
import {C, mono, sans} from '../styles/theme';

export const Investigation: FC<{t0: number}> = () => {
  const f = useCurrentFrame();
  return (
    <Shell glow="#1a2233" zoom={[1.05, 1]}>
      <div style={{position: 'absolute', right: 40, bottom: 130, opacity: 0.5}}>
        <PoliceBuilding w={760} />
      </div>
      <div style={{position: 'absolute', left: 160, top: 120, width: 1100, height: 620, background: 'rgba(16,21,29,0.92)', border: `2px solid ${C.line}`, padding: '44px 56px'}}>
        <div style={{fontFamily: mono, color: C.amber, fontSize: 30, letterSpacing: 6}}>BERKAS · PENYELIDIKAN</div>
        <div style={{fontFamily: sans, fontWeight: 800, fontSize: 64, color: C.text, margin: '26px 0 36px', opacity: ramp(f, 8)}}>SEJUMLAH ANGGOTA KEPOLISIAN</div>
        {[0.92, 0.7, 0.84, 0.55].map((w, i) => (
          <div key={i} style={{height: 30, background: '#2b3544', margin: '22px 0', width: `${ramp(f, 24 + i * 14, 24) * w * 100}%`}} />
        ))}
        <div style={{position: 'absolute', right: 50, bottom: 50, border: `5px solid ${C.red}`, color: C.red, fontFamily: sans, fontWeight: 900, fontSize: 44, letterSpacing: 4, padding: '8px 22px', transform: 'rotate(-8deg)', opacity: ramp(f, 80, 10)}}>
          DALAM PENYELIDIKAN
        </div>
      </div>
      <div style={{position: 'absolute', right: 180, top: 140, opacity: ramp(f, 20)}}>
        <CctvIcon size={220} color={C.red} />
      </div>
    </Shell>
  );
};
