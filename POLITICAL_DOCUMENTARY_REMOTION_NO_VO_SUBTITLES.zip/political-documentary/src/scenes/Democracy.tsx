import {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {Words, ramp} from '../animations/anim';
import {Chip} from '../components/Chip';
import {ScalesIcon} from '../components/icons';
import {Shell} from '../components/Shell';
import {lineFrames} from '../timeline';
import {C} from '../styles/theme';

export const Democracy: FC<{t0: number}> = ({t0}) => {
  const f = useCurrentFrame();
  const at = (i: number) => lineFrames(i).from - t0;
  return (
    <Shell glow="#14263a" zoom={[1, 1.08]}>
      <div style={{position: 'absolute', top: 90, left: 160, right: 160}}>
        <Words text="KEWENANGAN MENGAWASI BUKAN KEWENANGAN TANPA BATAS" at={at(18)} size={62} />
      </div>
      <div style={{position: 'absolute', left: 710, top: 260, opacity: 0.9 * ramp(f, at(18) + 20, 30), transform: `rotate(${Math.sin(f / 25) * 3}deg)`}}>
        <ScalesIcon size={500} color={C.amber} />
      </div>
      <Chip text="MENJAGA KEAMANAN NEGARA" at={at(19)} style={{position: 'absolute', left: 120, top: 700}} />
      <Chip text="DI BAWAH PENGAWASAN HUKUM" at={at(20)} color={C.amber} style={{position: 'absolute', right: 120, top: 700}} />
    </Shell>
  );
};
