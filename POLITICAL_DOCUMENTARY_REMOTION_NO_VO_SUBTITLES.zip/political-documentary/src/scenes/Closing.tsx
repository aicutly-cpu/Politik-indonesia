import {FC} from 'react';
import {useCurrentFrame, useVideoConfig} from 'remotion';
import {Words, win} from '../animations/anim';
import {EyeIcon} from '../components/icons';
import {Shell} from '../components/Shell';
import {lineFrames} from '../timeline';
import {C, mono, sans} from '../styles/theme';

export const Closing: FC<{t0: number}> = ({t0}) => {
  const f = useCurrentFrame();
  const {durationInFrames: d} = useVideoConfig();
  const at = (i: number) => lineFrames(i).from - t0;
  const center = {position: 'absolute', left: 120, right: 120, top: 330, textAlign: 'center'} as const;
  return (
    <Shell glow="#2a1216" zoom={[1, 1.1]}>
      <div style={{...center, opacity: win(f, at(21), at(22))}}>
        <div style={{fontFamily: mono, color: C.muted, fontSize: 34, letterSpacing: 8}}>BUKAN HANYA TENTANG</div>
        <div style={{fontFamily: sans, fontWeight: 900, fontSize: 96, marginTop: 30, color: C.text}}>
          YANG MENYADAP <span style={{color: C.red}}>·</span> YANG DISADAP
        </div>
      </div>
      <div style={{...center, opacity: win(f, at(22), at(23))}}>
        {['BATAS KEKUASAAN', 'TRANSPARANSI', 'KEPERCAYAAN MASYARAKAT'].map((t, i) => (
          <div key={t} style={{fontFamily: sans, fontWeight: 900, fontSize: 84, color: i === 1 ? C.amber : C.text, margin: '12px 0'}}>{t}</div>
        ))}
      </div>
      <div style={{...center, opacity: win(f, at(23), at(24))}}>
        <Words text="SIAPA YANG SEDANG DIAWASI?" at={at(23)} size={90} color={C.muted} />
      </div>
      <div style={{...center, top: 230, opacity: win(f, at(24), d + 20, 14)}}>
        <EyeIcon size={170} color={C.red} />
        <Words text="SIAPA YANG MENGAWASI PARA PENGAWAS?" at={at(24)} size={84} stagger={5} style={{marginTop: 30}} />
      </div>
    </Shell>
  );
};
