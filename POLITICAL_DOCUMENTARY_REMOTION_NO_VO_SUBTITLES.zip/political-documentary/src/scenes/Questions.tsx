import {FC} from 'react';
import {useCurrentFrame} from 'remotion';
import {Words, ramp} from '../animations/anim';
import {CctvIcon, EyeIcon, LockIcon} from '../components/icons';
import {Shell} from '../components/Shell';
import {lineFrames} from '../timeline';
import {C, sans} from '../styles/theme';

const CARDS = [
  {id: 15, label: 'MEKANISME PENGAWASAN', Icon: EyeIcon},
  {id: 16, label: 'PENGGUNAAN TEKNOLOGI PENGAWASAN', Icon: CctvIcon},
  {id: 17, label: 'PERLINDUNGAN PRIVASI WARGA', Icon: LockIcon},
];

export const Questions: FC<{t0: number}> = ({t0}) => {
  const f = useCurrentFrame();
  const at = (i: number) => lineFrames(i).from - t0;
  return (
    <Shell glow="#1b1f33" zoom={[1, 1.07]}>
      <div style={{position: 'absolute', top: 100, left: 120, right: 120}}>
        <Words text="ADA PERTANYAAN YANG JAUH LEBIH BESAR" at={at(14)} size={72} />
      </div>
      {CARDS.map(({id, label, Icon}, i) => {
        const p = ramp(f, at(id), 18);
        const next = i < 2 ? at(CARDS[i + 1].id) : Infinity;
        const current = f >= at(id) && f < next;
        return (
          <div key={id} style={{position: 'absolute', left: 120 + i * 580, top: 340, width: 520, height: 400, border: `3px solid ${current ? C.red : C.line}`, background: 'rgba(13,17,23,0.85)', display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 36, opacity: p * (current ? 1 : 0.55), transform: `translateY(${(1 - p) * 50}px)`}}>
            <Icon size={150} color={current ? C.red : C.text} />
            <div style={{fontFamily: sans, fontWeight: 800, fontSize: 36, letterSpacing: 2, textAlign: 'center', padding: '0 30px', color: C.text}}>{label}?</div>
          </div>
        );
      })}
    </Shell>
  );
};
