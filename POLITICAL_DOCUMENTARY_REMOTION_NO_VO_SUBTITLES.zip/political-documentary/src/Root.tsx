import {FC} from 'react';
import {Composition} from 'remotion';
import {Documentary} from './Video';
import {FPS, TOTAL_FRAMES} from './timeline';

export const RemotionRoot: FC = () => (
  <Composition id="PoliticalDocumentary" component={Documentary} durationInFrames={TOTAL_FRAMES} fps={FPS} width={1920} height={1080} />
);
