import {FC} from 'react';
import {AbsoluteFill, Audio, Sequence, interpolate, staticFile} from 'remotion';
import {Closing} from './scenes/Closing';
import {Democracy} from './scenes/Democracy';
import {Investigation} from './scenes/Investigation';
import {Opening} from './scenes/Opening';
import {Origin} from './scenes/Origin';
import {Paradox} from './scenes/Paradox';
import {Questions} from './scenes/Questions';
import {Targets} from './scenes/Targets';
import {Intro, Outro} from './scenes/TitleCards';
import {Verdict} from './scenes/Verdict';
import {C} from './styles/theme';
import {HAS_AUDIO, INTRO, NARR, OUTRO, TOTAL_FRAMES, scenes} from './timeline';

const MAP: Record<string, FC<{t0: number}>> = {
  opening: Opening,
  paradox: Paradox,
  origin: Origin,
  targets: Targets,
  investigation: Investigation,
  verdict: Verdict,
  questions: Questions,
  democracy: Democracy,
  closing: Closing,
};

export const Documentary: FC = () => {
  const base = HAS_AUDIO ? 0.12 : 0.4;
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <Audio
        src={staticFile('audio/ambient.mp3')}
        loop
        volume={(f) => interpolate(f, [0, 45, TOTAL_FRAMES - 60, TOTAL_FRAMES], [0, base, base, 0], {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'})}
      />
      <Sequence from={0} durationInFrames={INTRO}>
        <Intro />
      </Sequence>
      {scenes.map((s) => {
        const Scene = MAP[s.id];
        return (
          <Sequence key={s.id} from={s.from} durationInFrames={s.dur}>
            <Scene t0={s.from} />
          </Sequence>
        );
      })}
      <Sequence from={INTRO + NARR} durationInFrames={OUTRO}>
        <Outro />
      </Sequence>
    </AbsoluteFill>
  );
};
